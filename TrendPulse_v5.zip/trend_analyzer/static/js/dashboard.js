/* TrendPulse v5 — Professional Dashboard JS */
'use strict';

// ── Chart registry ────────────────────────────────────────────────────────────
const charts = {};
function mkChart(id, cfg){
  if(charts[id]) charts[id].destroy();
  const el = document.getElementById(id);
  if(!el) return;
  charts[id] = new Chart(el.getContext('2d'), cfg);
}

// ── Platform metadata ─────────────────────────────────────────────────────────
const PM = {
  YouTube:   {icon:'▶️', color:'#ff0000', label:'YouTube'},
  Instagram: {icon:'📸', color:'#e1306c', label:'Instagram'},
  TikTok:    {icon:'🎵', color:'#fe2c55', label:'TikTok'},
  Twitter:   {icon:'🐦', color:'#1d9bf0', label:'Twitter/X'},
  LinkedIn:  {icon:'💼', color:'#0a66c2', label:'LinkedIn'},
  Reddit:    {icon:'🤖', color:'#ff4500', label:'Reddit'},
  Snapchat:  {icon:'👻', color:'#f7c300', label:'Snapchat'},
  Pinterest: {icon:'📌', color:'#e60023', label:'Pinterest'},
  WhatsApp:  {icon:'💬', color:'#25d366', label:'WhatsApp'},
  Amazon:    {icon:'🛒', color:'#ff9900', label:'Amazon'},
};

// Trending card configs per slot
const TC_CFG = {
  'tc-all':           {icon:'🌐', title:'Overall Trending Topics',       key:'trending_all',           color:'#6366f1', badge:'All Platforms'},
  'tc-youtube':       {icon:'▶️', title:'YouTube Trending Topics',       key:'trending_youtube',       color:'#ff0000', badge:'YouTube Only'},
  'tc-instagram':     {icon:'📸', title:'Instagram Trending Topics',     key:'trending_instagram',     color:'#e1306c', badge:'Instagram Only'},
  'tc-tiktok':        {icon:'🎵', title:'TikTok Trending Topics',        key:'trending_tiktok',        color:'#fe2c55', badge:'TikTok Only'},
  'tc-twitter':       {icon:'🐦', title:'Twitter/X Trending Topics',     key:'trending_twitter',       color:'#1d9bf0', badge:'Twitter Only'},
  'tc-linkedin':      {icon:'💼', title:'LinkedIn Trending Topics',      key:'trending_linkedin',      color:'#0a66c2', badge:'LinkedIn Only'},
  'tc-sports':        {icon:'🏆', title:'Sports Trending Topics',        key:'trending_sports',        color:'#22c55e', badge:'Sports Category'},
  'tc-entertainment': {icon:'🎬', title:'Entertainment Trending Topics', key:'trending_entertainment', color:'#a855f7', badge:'Entertainment'},
  'tc-movies':        {icon:'⭐', title:'IMDb Movie Trending Topics',    key:'trending_movies',        color:'#f5c518', badge:'IMDb Dataset'},
  'tc-amazon':        {icon:'🛒', title:'Amazon Product Trending Topics',key:'trending_amazon',        color:'#ff9900', badge:'Amazon Dataset'},
};

// Chart.js defaults
Chart.defaults.color = '#4b5a75';
Chart.defaults.font.family = "'Inter', sans-serif";
Chart.defaults.font.size = 11;

// ── Navigation ────────────────────────────────────────────────────────────────
function show(name) {
  document.querySelectorAll('.content-section').forEach(s => s.classList.add('hidden'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  const sec = document.getElementById('section-' + name);
  if(sec) sec.classList.remove('hidden');
  document.querySelectorAll('.nav-item').forEach(n => {
    const oc = n.getAttribute('onclick') || '';
    if(oc.includes(`'${name}'`)) n.classList.add('active');
  });
}

function fp(platform) {
  document.getElementById('platFilter').value = platform;
  runAnalysis();
  show('platforms');
}

function qs(kw) {
  document.getElementById('searchInput').value = kw;
  runAnalysis();
}

// ── Main analysis ─────────────────────────────────────────────────────────────
async function runAnalysis() {
  const keyword  = document.getElementById('searchInput').value.trim();
  const category = document.getElementById('catFilter').value;
  const platform = document.getElementById('platFilter').value;
  const dataset  = document.getElementById('dsFilter').value;

  showLoader(true); hideNoRes();
  try {
    const r = await fetch('/api/analyze', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({keyword, category, platform, dataset})
    });
    if(!r.ok) throw new Error('Server error ' + r.status);
    const d = await r.json();
    showLoader(false);
    if(d.total === 0) { showNoRes(keyword || 'this filter'); return; }
    renderAll(d);
  } catch(e) {
    showLoader(false);
    alert('⚠ Cannot connect to server.\nMake sure: python app.py is running!\n\n' + e.message);
  }
}

function showLoader(on) {
  document.getElementById('loader').classList.toggle('hidden', !on);
  document.querySelectorAll('.content-section').forEach(s => s.classList.toggle('hidden', on));
}
function showNoRes(kw) {
  document.getElementById('noKw').textContent = `"${kw}"`;
  document.getElementById('noResults').classList.remove('hidden');
  document.querySelectorAll('.content-section').forEach(s => s.classList.add('hidden'));
}
function hideNoRes() { document.getElementById('noResults').classList.add('hidden'); }
function set(id, val) { const e = document.getElementById(id); if(e) e.textContent = val; }

// ── Master render ─────────────────────────────────────────────────────────────
function renderAll(d) {
  // Stat cards
  set('sTotal',  d.total);
  set('sSub',    d.keyword ? `"${d.keyword}"` : `${d.category !== 'All' ? d.category + ' · ' : ''}${d.platform !== 'All' ? d.platform : 'All platforms'}`);
  set('sPos',    d.sentiment_counts.positive);
  set('sPosPct', d.sentiment_pct.positive + '% of posts');
  set('sNeg',    d.sentiment_counts.negative);
  set('sNegPct', d.sentiment_pct.negative + '% of posts');
  set('sEng',    d.avg_engagement);
  set('sLikes',  d.avg_likes);
  set('sShares', d.avg_retweets);

  // Charts
  renderDonut(d.sentiment_counts);
  renderLine(d.trend_over_time);
  renderBar(d.sentiment_counts);
  renderMeter(d.sentiment_pct);
  renderPlatBar(d.platform_breakdown || {});
  renderCatPie(d.cat_breakdown || {});
  renderPlatPie(d.platform_breakdown || {});

  // ALL trending cards — each unique per platform/category
  Object.entries(TC_CFG).forEach(([slot, cfg]) => {
    renderTrendingCard(slot, cfg, d[cfg.key] || []);
  });

  // Platform cards
  renderPlatformCards(d.platform_stats || {}, d.platform_breakdown || {});

  // Dataset cards
  renderDatasetCards(d.dataset_stats || {});
  renderRatingCharts(d.rating_dist || {});

  // Keywords
  renderKeywords(d.top_keywords || []);
  renderHashtags(d.top_hashtags || []);
  renderKwChart(d.top_keywords || []);

  // Posts
  renderPosts('postList',          d.sample_posts || []);
  renderPosts('sportsList',        d.sports_posts || []);
  renderPosts('entertainmentList', d.entertainment_posts || []);
  renderPosts('moviesList',        d.movies_posts || []);
  renderPosts('amazonList',        d.amazon_posts || []);
  renderPosts('ytList',            d.youtube_posts || []);
  renderPosts('igList',            d.instagram_posts || []);
  renderPosts('ttList',            d.tiktok_posts || []);
  renderPosts('twList',            d.twitter_posts || []);
  renderPosts('liList',            d.linkedin_posts || []);
  renderPosts('reList',            d.reddit_posts || []);
}

// ── Donut chart ───────────────────────────────────────────────────────────────
function renderDonut(c) {
  mkChart('donutChart', {
    type: 'doughnut',
    data: {
      labels: ['Positive 😊','Negative 😞','Neutral 😐'],
      datasets: [{
        data: [c.positive, c.negative, c.neutral],
        backgroundColor: ['rgba(34,197,94,0.8)','rgba(239,68,68,0.8)','rgba(99,102,241,0.8)'],
        borderColor: ['#22c55e','#ef4444','#6366f1'],
        borderWidth: 1, hoverOffset: 8
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false, cutout: '68%',
      plugins: {
        legend: {position:'bottom', labels:{padding:14, usePointStyle:true, color:'#94a3b8'}},
        tooltip: {callbacks: {label: ctx => ` ${ctx.label}: ${ctx.parsed} posts`}}
      }
    }
  });
}

// ── Line chart ────────────────────────────────────────────────────────────────
function renderLine(t) {
  mkChart('lineChart', {
    type: 'line',
    data: {
      labels: t.labels,
      datasets: [
        {label:'Positive 😊', data:t.positive, borderColor:'#22c55e', backgroundColor:'rgba(34,197,94,0.08)', tension:0.4, fill:true, pointRadius:3, borderWidth:2},
        {label:'Negative 😞', data:t.negative, borderColor:'#ef4444', backgroundColor:'rgba(239,68,68,0.08)', tension:0.4, fill:true, pointRadius:3, borderWidth:2},
        {label:'Neutral 😐',  data:t.neutral,  borderColor:'#6366f1', backgroundColor:'rgba(99,102,241,0.08)',tension:0.4, fill:true, pointRadius:3, borderWidth:2},
      ]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      interaction: {mode:'index', intersect:false},
      scales: {
        x: {grid:{color:'rgba(255,255,255,0.04)'}, ticks:{color:'#4b5a75'}},
        y: {grid:{color:'rgba(255,255,255,0.04)'}, beginAtZero:true, ticks:{color:'#4b5a75', stepSize:1}}
      },
      plugins: {legend:{position:'top', labels:{usePointStyle:true, color:'#94a3b8', padding:12}}}
    }
  });
}

// ── Bar chart ─────────────────────────────────────────────────────────────────
function renderBar(c) {
  mkChart('barChart', {
    type: 'bar',
    data: {
      labels: ['😊 Positive','😞 Negative','😐 Neutral'],
      datasets: [{
        label: 'Number of Posts',
        data: [c.positive, c.negative, c.neutral],
        backgroundColor: ['rgba(34,197,94,0.7)','rgba(239,68,68,0.7)','rgba(99,102,241,0.7)'],
        borderColor: ['#22c55e','#ef4444','#6366f1'],
        borderWidth: 1, borderRadius: 6
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      scales: {
        x: {grid:{display:false}, ticks:{color:'#94a3b8', font:{size:12, family:'Inter'}}},
        y: {grid:{color:'rgba(255,255,255,0.04)'}, beginAtZero:true, ticks:{color:'#4b5a75'}}
      },
      plugins: {
        legend: {display:false},
        tooltip: {callbacks:{label: ctx => ` ${ctx.parsed.y} posts`}}
      }
    }
  });
}

// ── Platform bar ──────────────────────────────────────────────────────────────
function renderPlatBar(b) {
  const entries = Object.entries(b).filter(([,v]) => v > 0).sort(([,a],[,b]) => b-a);
  mkChart('platBarChart', {
    type: 'bar',
    data: {
      labels: entries.map(([k]) => `${PM[k]?.icon||'📱'} ${k}`),
      datasets: [{
        label: 'Posts',
        data: entries.map(([,v]) => v),
        backgroundColor: entries.map(([k]) => (PM[k]?.color||'#6366f1')+'bb'),
        borderColor: entries.map(([k]) => PM[k]?.color||'#6366f1'),
        borderWidth: 1, borderRadius: 6
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      scales: {
        x: {grid:{display:false}, ticks:{color:'#94a3b8', font:{size:10}}},
        y: {grid:{color:'rgba(255,255,255,0.04)'}, beginAtZero:true, ticks:{color:'#4b5a75'}}
      },
      plugins: {legend:{display:false}}
    }
  });
}

// ── Category pie ──────────────────────────────────────────────────────────────
function renderCatPie(b) {
  const entries = Object.entries(b).filter(([,v]) => v > 0).sort(([,a],[,b]) => b-a).slice(0, 10);
  const colors = ['#6366f1','#22c55e','#ef4444','#fe2c55','#ff0000','#1d9bf0','#0a66c2','#ff4500','#25d366','#f59e0b'];
  mkChart('catPieChart', {
    type: 'doughnut',
    data: {
      labels: entries.map(([k]) => k),
      datasets: [{
        data: entries.map(([,v]) => v),
        backgroundColor: colors.slice(0, entries.length).map(c => c + 'cc'),
        borderColor: colors.slice(0, entries.length),
        borderWidth: 1, hoverOffset: 6
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false, cutout: '50%',
      plugins: {legend:{position:'right', labels:{padding:10, usePointStyle:true, color:'#94a3b8', font:{size:10}}}}
    }
  });
}

// ── Platform pie ──────────────────────────────────────────────────────────────
function renderPlatPie(b) {
  const entries = Object.entries(b).filter(([,v]) => v > 0);
  mkChart('platPieChart', {
    type: 'doughnut',
    data: {
      labels: entries.map(([k]) => `${PM[k]?.icon||'📱'} ${k}`),
      datasets: [{
        data: entries.map(([,v]) => v),
        backgroundColor: entries.map(([k]) => (PM[k]?.color||'#6366f1')+'cc'),
        borderColor: entries.map(([k]) => PM[k]?.color||'#6366f1'),
        borderWidth: 1, hoverOffset: 6
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false, cutout: '55%',
      plugins: {legend:{position:'right', labels:{padding:10, usePointStyle:true, color:'#94a3b8', font:{size:10}}}}
    }
  });
}

// ── Rating charts ─────────────────────────────────────────────────────────────
function renderRatingCharts(rd) {
  const buckets = ['1–3 ⭐','4–6 ⭐','7–8 ⭐','9–10 ⭐'];
  if(rd.imdb) {
    mkChart('imdbChart', {
      type: 'bar',
      data: {labels:buckets, datasets:[{label:'Movies', data:Object.values(rd.imdb),
        backgroundColor:['rgba(239,68,68,0.7)','rgba(249,115,22,0.7)','rgba(34,197,94,0.7)','rgba(99,102,241,0.7)'],
        borderColor:['#ef4444','#f97316','#22c55e','#6366f1'], borderWidth:1, borderRadius:6}]},
      options:{responsive:true,maintainAspectRatio:false,
        scales:{x:{grid:{display:false},ticks:{color:'#94a3b8'}},y:{grid:{color:'rgba(255,255,255,0.04)'},beginAtZero:true,ticks:{color:'#4b5a75'}}},
        plugins:{legend:{display:false}}}
    });
  }
  if(rd.amazon) {
    mkChart('amazonChart', {
      type: 'bar',
      data: {labels:buckets, datasets:[{label:'Products', data:Object.values(rd.amazon),
        backgroundColor:['rgba(239,68,68,0.7)','rgba(249,115,22,0.7)','rgba(245,158,11,0.7)','rgba(34,197,94,0.7)'],
        borderColor:['#ef4444','#f97316','#f59e0b','#22c55e'], borderWidth:1, borderRadius:6}]},
      options:{responsive:true,maintainAspectRatio:false,
        scales:{x:{grid:{display:false},ticks:{color:'#94a3b8'}},y:{grid:{color:'rgba(255,255,255,0.04)'},beginAtZero:true,ticks:{color:'#4b5a75'}}},
        plugins:{legend:{display:false}}}
    });
  }
}

// ── Trending card renderer ────────────────────────────────────────────────────
function renderTrendingCard(slot, cfg, topics) {
  const el = document.getElementById(slot);
  if(!el) return;
  const maxEng = topics.length ? Math.max(...topics.map(t => t.avg_eng || t.score || 0)) : 1;
  const rows = topics.slice(0, 8).map((t, i) => {
    const rankClass = i === 0 ? 'top1' : i === 1 ? 'top2' : i === 2 ? 'top3' : '';
    const rankSym   = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `${i+1}`;
    const eng = Math.round(t.avg_eng || t.score || 0);
    const pct = maxEng > 0 ? Math.round(eng / maxEng * 100) : 0;
    return `
      <div class="t-item" onclick="qs('${t.tag.replace('#','')}')">
        <span class="t-rank ${rankClass}">${rankSym}</span>
        <div style="flex:1;min-width:0">
          <div style="display:flex;align-items:center;gap:6px">
            <span class="t-tag">${t.tag}</span>
            <span class="t-cat">${t.category||''}</span>
            <span class="t-eng" style="margin-left:auto">🔥 ${eng.toLocaleString()}</span>
          </div>
          <div class="t-bar"><div class="t-bar-fill" style="width:${pct}%"></div></div>
        </div>
      </div>`;
  }).join('');

  el.innerHTML = `
    <div class="trending-card" style="--tc:${cfg.color}">
      <div class="trending-card-header">
        <span class="tc-icon">${cfg.icon}</span>
        <span class="tc-title">${cfg.title}</span>
        <span class="tc-badge">${cfg.badge}</span>
      </div>
      <div class="t-list">
        ${rows || '<p style="color:var(--text3);font-size:12px;padding:8px">No trending topics found.</p>'}
      </div>
    </div>`;
}

// ── Meters ────────────────────────────────────────────────────────────────────
function renderMeter(p) {
  const el = document.getElementById('meterRow');
  if(!el) return;
  el.innerHTML = `
    <div class="meter-card"><span class="meter-emoji">😊</span><div class="meter-label">Positive Sentiment</div><div class="meter-pct m-p">${p.positive}%</div></div>
    <div class="meter-card"><span class="meter-emoji">😞</span><div class="meter-label">Negative Sentiment</div><div class="meter-pct m-n">${p.negative}%</div></div>
    <div class="meter-card"><span class="meter-emoji">😐</span><div class="meter-label">Neutral Sentiment</div><div class="meter-pct m-u">${p.neutral}%</div></div>`;
}

// ── Platform cards ────────────────────────────────────────────────────────────
function renderPlatformCards(stats, breakdown) {
  const el = document.getElementById('platformCards');
  if(!el) return;
  el.innerHTML = Object.entries(stats).map(([p, s]) => {
    const m = PM[p] || {icon:'📱', color:'#6366f1'};
    return `
    <div class="platform-card" style="--pc:${m.color}" onclick="fp('${p}')">
      <div class="pc-top">
        <span class="pc-icon">${m.icon}</span>
        <span class="pc-name">${p}</span>
        <span class="pc-count">${s.total} posts</span>
      </div>
      <div class="mini-bars">
        <div class="mini-bar"><span class="mini-label">😊</span><div class="mini-track"><div class="mini-fill mf-p" style="width:${s.positive}%"></div></div><span class="mini-pct">${s.positive}%</span></div>
        <div class="mini-bar"><span class="mini-label">😞</span><div class="mini-track"><div class="mini-fill mf-n" style="width:${s.negative}%"></div></div><span class="mini-pct">${s.negative}%</span></div>
        <div class="mini-bar"><span class="mini-label">😐</span><div class="mini-track"><div class="mini-fill mf-u" style="width:${s.neutral}%"></div></div><span class="mini-pct">${s.neutral}%</span></div>
      </div>
    </div>`;
  }).join('');
}

// ── Dataset cards ─────────────────────────────────────────────────────────────
function renderDatasetCards(stats) {
  const el = document.getElementById('datasetCards');
  if(!el) return;
  const meta = {
    IMDb:    {icon:'🎬', color:'#f5c518', title:'IMDb Dataset', sub:'Movie Reviews & Ratings'},
    Amazon:  {icon:'🛒', color:'#ff9900', title:'Amazon Dataset', sub:'Product Reviews & Ratings'},
    Twitter: {icon:'📱', color:'#1d9bf0', title:'Social Media Dataset', sub:'Posts from 9 Platforms'},
  };
  el.innerHTML = Object.entries(stats).map(([d, s]) => {
    const m = meta[d] || {icon:'📊', color:'#6366f1', title:d, sub:'Dataset'};
    return `
    <div class="info-card" style="--ic:${m.color}">
      <div class="ic-header"><span class="ic-icon">${m.icon}</span><div><div class="ic-title">${m.title}</div><div class="ic-subtitle">${m.sub} · ${s.total} records</div></div></div>
      <div class="ic-stats">
        <div class="ic-row"><span class="ic-label">😊 Positive</span><span class="ic-val" style="color:#22c55e">${s.positive}%</span></div>
        <div class="ic-bar-wrap"><div class="ic-bar" style="width:${s.positive}%;background:#22c55e"></div></div>
        <div class="ic-row" style="margin-top:6px"><span class="ic-label">😞 Negative</span><span class="ic-val" style="color:#ef4444">${s.negative}%</span></div>
        <div class="ic-bar-wrap"><div class="ic-bar" style="width:${s.negative}%;background:#ef4444"></div></div>
        ${s.avg_rating ? `<div class="ic-row" style="margin-top:8px"><span class="ic-label">⭐ Avg Rating</span><span class="ic-val" style="color:#f59e0b">${s.avg_rating}/10</span></div>` : ''}
      </div>
    </div>`;
  }).join('');
}

// ── Keywords ──────────────────────────────────────────────────────────────────
function renderKeywords(kws) {
  const el = document.getElementById('keywordList');
  if(!el) return;
  if(!kws.length) { el.innerHTML = '<p style="color:var(--text3);font-size:12px;padding:8px">No keywords found.</p>'; return; }
  const max = kws[0].count;
  el.innerHTML = kws.slice(0, 12).map((k, i) => `
    <div class="kw-item">
      <span class="kw-rank">${i+1}</span>
      <span class="kw-word">${k.word}</span>
      <div class="kw-track"><div class="kw-bar" style="width:${(k.count/max*100).toFixed(1)}%"></div></div>
      <span class="kw-count">${k.count}×</span>
    </div>`).join('');
}

function renderHashtags(tags) {
  const el = document.getElementById('hashtagList');
  if(!el) return;
  if(!tags.length) { el.innerHTML = '<p style="color:var(--text3);font-size:12px;padding:8px">No hashtags found.</p>'; return; }
  const max = tags[0].count;
  el.innerHTML = tags.slice(0, 12).map((h, i) => `
    <div class="kw-item">
      <span class="kw-rank">${i+1}</span>
      <span class="kw-word" style="color:var(--primary)">${h.tag}</span>
      <div class="kw-track"><div class="kw-bar" style="width:${(h.count/max*100).toFixed(1)}%;background:linear-gradient(90deg,#ec4899,#a855f7)"></div></div>
      <span class="kw-count">${h.count}×</span>
    </div>`).join('');
}

function renderKwChart(kws) {
  const top = kws.slice(0, 10);
  mkChart('kwChart', {
    type: 'bar',
    data: {
      labels: top.map(k => k.word),
      datasets: [{
        label: 'Frequency',
        data: top.map(k => k.count),
        backgroundColor: top.map((_, i) => `hsla(${240+i*18},65%,55%,0.7)`),
        borderColor: top.map((_, i) => `hsl(${240+i*18},65%,65%)`),
        borderWidth: 1, borderRadius: 5
      }]
    },
    options: {
      indexAxis: 'y', responsive: true, maintainAspectRatio: false,
      scales: {
        x: {grid:{color:'rgba(255,255,255,0.04)'}, beginAtZero:true, ticks:{color:'#4b5a75'}},
        y: {grid:{display:false}, ticks:{color:'#94a3b8', font:{size:11}}}
      },
      plugins: {legend:{display:false}}
    }
  });
}

// ── Post cards ────────────────────────────────────────────────────────────────
function renderPosts(elId, posts) {
  const el = document.getElementById(elId);
  if(!el) return;
  if(!posts.length) { el.innerHTML = '<p style="color:var(--text3);font-size:12px;padding:10px">No posts found for this filter.</p>'; return; }
  const icons = {positive:'😊', negative:'😞', neutral:'😐'};
  el.innerHTML = posts.map((p, i) => {
    const plat = p.platform || '';
    const m = PM[plat] || {icon:'📱'};
    const rating = p.rating && +p.rating > 0 && +p.rating <= 10 ? `<span class="post-rating">⭐ ${(+p.rating).toFixed(1)}/10</span>` : '';
    const ds = p.dataset && p.dataset !== plat ? `<span class="post-plat" style="color:var(--warning)">${p.dataset}</span>` : '';
    return `
    <div class="post-card ps-${p.sentiment}" style="animation-delay:${i*0.06}s">
      <div class="post-sent ps-${p.sentiment}">${icons[p.sentiment]||'❓'}</div>
      <div class="post-body">
        <div class="post-text">${String(p.text||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}</div>
        <div class="post-tags">${p.hashtags||''}</div>
        <div class="post-meta">
          <span class="post-stat">❤ ${Number(p.likes||0).toLocaleString()}</span>
          <span class="post-stat">🔁 ${Number(p.retweets||0).toLocaleString()}</span>
          <span class="post-badge ${p.sentiment}">${p.sentiment}</span>
          ${rating}
          ${plat ? `<span class="post-plat">${m.icon} ${plat}</span>` : ''}
          ${ds}
        </div>
      </div>
    </div>`;
  }).join('');
}

// ── Live updates ──────────────────────────────────────────────────────────────
async function fetchLiveUpdates() {
  try {
    const r = await fetch('/api/live');
    if(!r.ok) return;
    const d = await r.json();

    // Update ticker
    const tickerEl = document.getElementById('tickerText');
    if(tickerEl && d.updates) {
      tickerEl.textContent = d.updates.map(u => `${PM[u.platform]?.icon||'📱'} ${u.platform}: ${u.text}`).join('   •   ');
    }
    set('tickerTime', d.time);
    set('liveTime', d.time);

    // Update live panel
    const el = document.getElementById('liveUpdatesList');
    if(el && d.updates) {
      el.innerHTML = d.updates.map((u, i) => `
        <div class="live-update-item">
          <span class="lui-icon">${PM[u.platform]?.icon||'📱'}</span>
          <div class="lui-body">
            <div class="lui-text">${u.text}</div>
            <div class="lui-meta">
              <span class="lui-plat">${u.platform}</span>
              <span class="lui-time">${u.time}</span>
              ${i === 0 ? '<span class="lui-new">● NEW</span>' : ''}
              <span class="post-stat" style="margin-left:auto">❤ ${Number(u.likes).toLocaleString()}</span>
            </div>
          </div>
        </div>`).join('');
    }
  } catch(e) {
    console.log('Live update fetch failed:', e.message);
  }
}

// ── Clock ─────────────────────────────────────────────────────────────────────
function updateClock() {
  const now = new Date();
  set('clock', now.toLocaleTimeString([], {hour:'2-digit', minute:'2-digit', second:'2-digit'}));
  set('dateBadge', now.toLocaleDateString([], {month:'short', day:'numeric', year:'numeric'}));
}

// ── Init ──────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  updateClock();
  setInterval(updateClock, 1000);

  document.getElementById('searchInput').addEventListener('keydown', e => {
    if(e.key === 'Enter') runAnalysis();
  });

  // Initial load
  runAnalysis();

  // Live updates every 15 seconds
  fetchLiveUpdates();
  setInterval(fetchLiveUpdates, 15000);
});
